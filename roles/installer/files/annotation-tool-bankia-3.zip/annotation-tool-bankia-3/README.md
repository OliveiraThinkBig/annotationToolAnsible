# Annotation Tool

Annotation Tool is a Web Application written in Scala.

## Prerequisites
Annotation Tool requires Java 1.8. To check that you have the latest JDK, please run:

```
java -version
```

If you don't have the JDK, you have to install it from [Oracle's JDK Site](http://www.oracle.com/technetwork/java/javase/downloads/index.html)

## Installing Annotation Tool with Activator
Refer to the Activator [download page](https://www.lightbend.com/activator/download) to install the activator launcher on your syatem.

### Clone
```
    $ git clone git@github.com:ThinkBigAnalytics/Aisin.git
```
### Anatomy of Annotation Tool
```
annotationtool/
├── app
├── conf
├── logs
├── project
│   ├── project
│   └── target
├── public
│   ├── css
│   ├── data
│   ├── images
│   └── js
├── target
│   └── streams
└── test
```

### Build
    
    sbt playGenerateSecret
    sbt playUpdateSecret
    
    sbt clean
    sbt compile 
    sbt run
    
    sbt dist

### Configuration
conf/application.conf
```
base.dir.img = "/home/aisin/Aisin/annotationtool/public"
base.path.img = "data"
img.path = "imgs-01"
base.dir.ann = "/home/aisin/Aisin/annotationtool/data"
ann.path.in = "ann"
ann.path.out = "ann"
```

### Put images
Our images directory is now "/home/aisin/Aisin/annotationtool/public/data/imags-01".
So put our images to the directory.
We can annotate agaist those images via annotation tool.


### Run
```
$ activator run
```

### Access
```
http://hostname:9000
```
